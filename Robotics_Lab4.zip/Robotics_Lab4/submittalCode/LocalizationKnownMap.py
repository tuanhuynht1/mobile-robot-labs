import encoders
import motorControl
import sensors
import printMaze
import models
import motion

import copy



def run():
    #X's represent walls, .'s are openings and O's are cells
    mazeMap = [ 
        ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', '.', 'X', 'X', 'X', 'X', 'X', '.', 'X'],
        ['X', 'O', 'X', 'O', '.', 'O', 'X', 'O', 'X'],
        ['X', '.', 'X', '.', '.', '.', 'X', '.', 'X'],
        ['X', 'O', '.', 'O', 'X', 'O', 'X', 'O', 'X'],
        ['X', '.', '.', 'X', 'X', '.', '.', '.', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'],
    ]

    
    cellID = [
        [1.0, 2.0, 3.0, 4.0],
        [5.0, 6.0, 7.0, 8.0],
        [9.0, 10.0, 11.0, 12.0],
        [13.0, 14.0, 15.0, 16.0],
    ]
    print("Maze Startup")
    printMaze.display(mazeMap, cellID)

    #initialize
    particles = [
        [1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1],
    ]
    # particles = [
    #     [16, 0, 0, 0],
    #     [0, 0, 0, 0],
    #     [0, 0, 0, 0],
    #     [0, 0, 0, 0],
    # ]
    #map of number of times a cell has been visited visited cells
    VisitedCells = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
    ]
    cellsVisitedCount = 0
    robotInfo = [3,3,'N']
    robotCell = robotInfo[1]*4 + robotInfo[0]
    print(" Initial Maze Setup")
    printMaze.display(mazeMap, cellID)
    print("Robot Info: " + str(robotCell)+ " " + robotInfo[2])
    while cellsVisitedCount < 16:


        #apply measuremnet model
        mM = models.measurementModel(mazeMap, particles, robotInfo)

        normMap = models.normalize(mM)

        #resample
        particles = models.resample(normMap, 16)

        robotInfo = models.loc(particles, robotInfo)
        if(VisitedCells[robotInfo[1]][robotInfo[0]] == 0):
            cellsVisitedCount +=1
            
        VisitedCells[robotInfo[1]][robotInfo[0]] += 1

        print("                Measurement Model                                Normalized Measures                                Particles")
        printMaze.multiDisplay(mazeMap, mM, normMap, particles)
        #motion
        robotInfo = motion.explore(robotInfo, mazeMap, VisitedCells)
        #apply motion model
        particles = models.motionModel(mazeMap,particles, robotInfo)

        print("                Cells Visited                                Updated Particles                                Cells")
        printMaze.multiDisplay(mazeMap, VisitedCells, particles, cellID)
        robotCell = robotInfo[1]*4 + robotInfo[0]
        print("Robot Info: " + str(robotCell) + robotInfo[2])
        if(cellsVisitedCount == 15):
            print("So long and thanks for all the fish")
            cellsVisitedCount += 1



