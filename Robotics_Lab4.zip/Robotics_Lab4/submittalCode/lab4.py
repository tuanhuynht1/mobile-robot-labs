import encoders
import motorControl
import sensors
import localizationOpenSpace
import LocalizationKnownMap
import LocalizationUnknownMap

import signal
import os
import time

import triangulation
import sensorTesting
import camTest
# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    sensors.lSensor.stop_ranging()
    sensors.fSensor.stop_ranging()
    sensors.rSensor.stop_ranging()
    exit()

# Attach the Ctrl+C signal interrupt
signal.signal(signal.SIGINT, ctrlC) 

#clear screen after sensors initialization
os.system('clear')

#initialize speed chart 
if motorControl.setChart() ==  False:
    motorControl.calibrateSpeeds()
    motorControl.setChart()

# #initialize ThreadedWebcam object
# camera = ThreadedWebcam.ThreadedWebcam()
# camera.start() 

while True:
    #parse command
    print("-------------------------------------------Command List---------------------------------------")
    print("[c] calibrate, [q] quit, [1] task 1, [2] task 2, [3] task 3, [4] task 4, [ENTER] clear screen")
    print("----------------------------------------------------------------------------------------------\n")
    cmd = input("Command: ")
    
    #software robustness
    if not cmd:
        os.system('clear')

    elif cmd[0] == '1':
        print("\ntask 1...") 
        localizationOpenSpace.run()
        # time.sleep(2)   
        # os.system('clear')

    elif cmd[0] == '2' :
        print("\ntask 2...")
        LocalizationKnownMap.run()
        # time.sleep(2)
        # os.system('clear')

    elif cmd[0] == '3' :
        print("\ntask 3...")
        LocalizationUnknownMap.run()
        # time.sleep(2)
        # os.system('clear')

    elif cmd[0] == '4' :
        
        camTest.run()
        # time.sleep(2)
        # os.system('clear')

    elif cmd[0] == '.' :
        print("\ndebugging...")
        sensorTesting.run()
        # os.system('clear')

    elif cmd[0] == 'q' :
        os.system('clear')
        motorControl.stop()
        encoders.cleanUp()
        sensors.lSensor.stop_ranging()
        sensors.fSensor.stop_ranging()
        sensors.rSensor.stop_ranging()
        exit()

    elif cmd[0] == 'c':
        print("\nRecalibrating...")
        motorControl.calibrateSpeeds()
        motorControl.setChart()
        os.system('clear')
        
    else:
        os.system('clear')
        print("\nCommand not found, try again\n")

 
