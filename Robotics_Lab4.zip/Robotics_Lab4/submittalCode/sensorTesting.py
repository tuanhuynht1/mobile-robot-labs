import encoders
import motorControl
import sensors
import printMaze

import signal
import os
import time
import math

import triangulation

def run():
    while True:
        print(sensors.getDistances())
        time.sleep(.5)