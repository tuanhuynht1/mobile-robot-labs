import encoders
import motorControl
import sensors
import printMaze

import signal
import os
import time
import math

import triangulation
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    sensors.lSensor.stop_ranging()
    sensors.fSensor.stop_ranging()
    sensors.rSensor.stop_ranging()
    sensors.writeCSV(distChart)
    print('\n\n\n ****** STOP *********')
    exit()


def run():
    #X's represent walls, .'s are openings and O's are cells
    mazeMap = [ 
        ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', '.', '.', '.', '.', '.', '.', '.', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', '.', '.', '.', '.', '.', '.', '.', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', '.', '.', '.', '.', '.', '.', '.', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'],
    ]

    
    cellID = [
        [1.0, 2.0, 3.0, 4.0],
        [5.0, 6.0, 7.0, 8.0],
        [9.0, 10.0, 11.0, 12.0],
        [13.0, 14.0, 15.0, 16.0],
    ]
    print("Maze Startup")
    printMaze.display(mazeMap, cellID)

    #initialize
    particles = [
        [1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1],
    ]
    #map of number of times a cell has been visited visited cells
    VisitedCells = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
    ]
    cellsVisitedCount = 0
    robotInfo = [3,3,'N']
    while cellsVisitedCount < 16:
        print(robotInfo)
        #apply measuremnet model
        mM = measurementModel(mazeMap, particles, robotInfo)
        print("Measurement Model")
        printMaze.display(mazeMap, mM)
        normMap = normalize(mM)
        print("Normalized Map")
        printMaze.display(mazeMap, normMap)
        #resample
        particles = resample(normMap, 16)
        print("Particle Map")
        printMaze.display(mazeMap, particles)
        robotInfo = loc(particles, robotInfo)
        if(VisitedCells[robotInfo[1]][robotInfo[0]]):
            cellsVisitedCount += 1
        VisitedCells[robotInfo[1]][robotInfo[0]] = 1
        print("Cells Visited")
        printMaze.display(mazeMap, VisitedCells)
        time.sleep(1)
        #motion
        robotInfo = explore(robotInfo, mazeMap, VisitedCells)
        #apply motion model
        particles = motionModel(mazeMap,particles, robotInfo)
        print("Motion Model applied to particles")
        printMaze.display(mazeMap, particles)
        time.sleep(1)

    #apply measuremnet model
    mM = measurementModel(mazeMap, particles, robotInfo)
    print("Measurement Model")
    printMaze.display(mazeMap, mM)
    normMap = normalize(mM)
    print("Normalized Map")
    printMaze.display(mazeMap, normMap)
    #resample
    particles = resample(normMap, 16)
    print("Final Particle Map")
    printMaze.display(mazeMap, particles)
    print("Cells Visited")
    printMaze.display(mazeMap, VisitedCells)


def loc(particleMap, robotInfo):
    particleMax = 0
    i = 0
    j = 0
    x = 0
    y = 0
    while j < 4:
        while i < 4:
            if particleMap[j][i] > particleMax:
                particleMax = particleMap[j][i]
                x=i
                y=j
            i += 1
        i = 0
        j+= 1
    robotInfo[0] = x
    robotInfo[1] = y
    return robotInfo

def measurementModel(mazeMap,particleMap,robotInfo):
    correctReading = 0.7
    incorrectReading = 0.3
    opening = 10
    x=0
    y=0
    n=0
    frontMeasures = []
    leftMeasures = []
    rightMeasures = []
    while n < 5:
        leftMeasures.append(sensors.getLeftDistance())
        rightMeasures.append(sensors.getRightDistance())
        frontMeasures.append(sensors.getFrontDistance())
        n+=1
    leftMeasures.sort(reverse=True)
    rightMeasures.sort(reverse=True)
    frontMeasures.sort(reverse=True)
    measures = [leftMeasures[0], frontMeasures[0], rightMeasures[0]]
    print("Measures " + str(measures))
    print("Robot Info " + str(robotInfo))
    model = []
    while y < 4:
        row = []
        while x < 4:

            prob = 1
            i = 2*x + 1
            j = 2*y + 1
            if(robotInfo[2] == 'N'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j-1][i] == '.')or(measures[1] <= opening and mazeMap[j-1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j][i-1] == '.')or(measures[0] <= opening and mazeMap[j][i-1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j][i+1] == '.')or(measures[2] <= opening and mazeMap[j][i+1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
            
            elif(robotInfo[2] == 'E'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j][i+1] == '.')or(measures[1] <= opening and mazeMap[j][i+1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j-1][i] == '.')or(measures[0] <= opening and mazeMap[j-1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j+1][i] == '.')or(measures[2] <= opening and mazeMap[j+1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]

            if(robotInfo[2] == 'S'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j+1][i] == '.')or(measures[1] <= opening and mazeMap[j+1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j][i+1] == '.')or(measures[0] <= opening and mazeMap[j][i+1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j][i-1] == '.')or(measures[2] <= opening and mazeMap[j][i-1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
            
            elif(robotInfo[2] == 'W'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j][i-1] == '.')or(measures[1] <= opening and mazeMap[j][i-1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j+1][i] == '.')or(measures[0] <= opening and mazeMap[j+1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j-1][i] == '.')or(measures[2] <= opening and mazeMap[j-1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
            row.append(prob)
            x += 1
        model.append(row)
        y+=1
        x = 0

    x=0
    y=0
    return model

def resample(measureProbabilities, particleNumber):
    #process: find highes probability locations, place particles based on probability, move to next highest, etc. until out of particles.
    maxUnusedProb = 0
    unusedParticles = particleNumber
    particleMap = [
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
    ]
    i = 0
    j = 0
    while unusedParticles >0:
        i = 0
        j = 0
        while j < 4:
            while i < 4:
                if measureProbabilities[j][i] > maxUnusedProb:
                    maxUnusedProb = measureProbabilities[j][i]
                i += 1
            i = 0
            j+= 1
        
        i=0
        j=0


        while j < 4:
            while i < 4:
                if measureProbabilities[j][i] == maxUnusedProb:
                    if (round(measureProbabilities[j][i] * particleNumber) >=1 ):
                        p = float(round(measureProbabilities[j][i] * particleNumber))
                    else:
                        p = 1.0
                    particleMap[j][i] = p
                    unusedParticles -= p
                    measureProbabilities[j][i] = 0
                if unusedParticles == 0:
                    return particleMap
                i += 1
            i = 0
            j+= 1
        maxUnusedProb = 0
    return particleMap
        
def motionModel(mazeMap, particleMap, robotInfo):
    correctMovement = 0.9
    incorrectMovement = 0.1

    x=0
    y=0

    model = particleMap
    while y < 4:
        while x < 4:

            # i and j are the mazeMap translated version of the particle map
            i = 2*x + 1
            j = 2*y + 1

            if(robotInfo[2] == 'N'):
                print("Move particles North")
                if (mazeMap[j-1][i] == '.'):
                    model[y-1][x] = particleMap[y][x] + particleMap[y-1][x]
                    particleMap[y][x] = 0.0
            
            if(robotInfo[2] == 'E'):
                print("Move particles East")
                if (mazeMap[j][i+1] == '.'):
                    model[y][x+1] = particleMap[y][x] + particleMap[y][x+1]
                    particleMap[y][x] = 0.0

            if(robotInfo[2] == 'S'):
                print("Move particles South")
                if (mazeMap[j+1][i] == '.'):
                    model[y+1][x] = particleMap[y][x] + particleMap[y+1][x]
                    particleMap[y][x] = 0.0

            if(robotInfo[2] == 'W'):
                print("Move particles West")
                if (mazeMap[j][i-1] == '.'):
                    model[y][x-1] = particleMap[y][x] + particleMap[y][x-1]
                    particleMap[y][x] = 0.0
            x += 1
        y+=1
        x = 0

    x=0
    y=0
    return model

def normalize(probabilityMap):
    normalizedMap = probabilityMap
    total = 0.0
    i=0
    j=0

    while j < 4:
        while i < 4:
            total += probabilityMap[j][i]
            i+=1
        j += 1
        i = 0
    i = 0
    j = 0

    while j < 4:
        while i < 4:
            normalizedMap[j][i] = probabilityMap[j][i]/total
            i += 1
        j += 1
        i = 0
    
    return normalizedMap
# keep the robot centered horizontally in cell as it moves.
def centeredSpeed(linearVelocity):
    desired = 8
    Kp = 2
    tollerance = 0.01
    ldist = sensors.getLeftDistance()
    rdist = sensors.getRightDistance()
    
    #neither wall is seen, can't center
    if(ldist > 13 and rdist > 13):
        return linearVelocity, linearVelocity
    
    #if only right wall is seen
    elif(ldist > 13 and rdist <=13):
        #too far from right wall
        if(rdist - desired > 0):
            error = min(rdist-desired, Kp)
            if linearVelocity > 0:
                return linearVelocity, linearVelocity - error
            else:
                return linearVelocity - error, linearVelocity
        
        #too close to right wall
        elif(rdist - desired < 0):
            error = min(desired-rdist, Kp)
            if linearVelocity > 0:
                return linearVelocity - error, linearVelocity
            else:
                return linearVelocity, linearVelocity - error
    
    #if only left wall is seen
    elif(rdist > 13 and ldist <= 13):
        #too far from left wall
        if(ldist - desired > 0):
            error = min(ldist-desired, Kp)
            if linearVelocity > 0:
                return linearVelocity-error, linearVelocity
            else:
                return linearVelocity, linearVelocity-error
        
        #too close to left wall
        elif(desired - ldist < 0):
            error = min(desired-ldist, Kp)
            if linearVelocity > 0:
                return linearVelocity, linearVelocity - error
            else:
                return linearVelocity - error, linearVelocity
    
    #both walls are seen
    else:
        if (ldist-rdist > tollerance):
            error = min(ldist - rdist, Kp)
            #left wheel should slow down to move closer to the left
            if linearVelocity > 0:    
                return linearVelocity - error , linearVelocity
            else:
                return linearVelocity, linearVelocity - error

        elif(ldist-rdist < -1*tollerance):
            error = min(rdist - ldist, Kp)
            #left wheel should slow down to move closer to the left
            if linearVelocity > 0:
                return linearVelocity, linearVelocity - error
            else:
                return linearVelocity - error , linearVelocity
        else:
            return linearVelocity, linearVelocity
    return linearVelocity, linearVelocity
def forward():
    print("Forward")
    x = 18
    y = 3
    desiredSpeed = x/y
    desiredDistance = 7

    if (abs(desiredSpeed) > motorControl.MAX_IPS):
        print("Impossible speed")
        sys.exit()

    totalTicks = (1/motorControl.IPT) * abs(x)
    lspeed, rspeed = centeredSpeed(desiredSpeed)
    motorControl.setSpeedsIPS(lspeed, rspeed)
    encoders.resetCount()


    while (encoders.getCounts()[0] < totalTicks and sensors.getFrontDistance() > desiredDistance):
        speeds = centeredSpeed(desiredSpeed)
        motorControl.setSpeedsIPS(speeds[0], speeds[1])
    
    motorControl.stop()
    print("forward finished")


def saturateLinear(velocity):
    if(velocity > motorControl.MAX_IPS):
        velocity = motorControl.MAX_IPS
    elif(velocity < -1*motorControl.MAX_IPS):
        velocity = -1*motorControl.MAX_IPS
    return velocity

def linearDesiredVelocity(desiredDist,Kp):
    # e(t) = r(t) - y(t)
    error = desiredDist - sensors.getFrontDistance()
    error = error * -1 # adjust velocity based on robot's perspective

    # u(t) = Kp * e(t)
    velocity = Kp * error

    #u_r(t) = fsat(u(t))
    velocity = saturateLinear(velocity)
    
    # motorControl.setSpeedsIPS(velocity,velocity)
    return velocity
def explore(robotInfo, mazeMap, VisitedCells):
    opening = 10
    
    #check if the robot should move in a direction
    print(robotInfo)
    north = False
    south = False
    east = False
    west = False
    frontMeasures = []
    leftMeasures = []
    rightMeasures = []
    n=0
    while n < 5:
        leftMeasures.append(sensors.getLeftDistance())
        rightMeasures.append(sensors.getRightDistance())
        frontMeasures.append(sensors.getFrontDistance())
        n+=1
    leftMeasures.sort(reverse=True)
    rightMeasures.sort(reverse=True)
    frontMeasures.sort(reverse=True)
    measures = [leftMeasures[0], frontMeasures[0], rightMeasures[0]]

    if(robotInfo[1] > 0):
        if(VisitedCells[robotInfo[1]-1][robotInfo[0]] == 0):
            north = True

    if(robotInfo[1] < 3):
        if(VisitedCells[robotInfo[1]+1][robotInfo[0]] == 0):
            south = True

    if(robotInfo[0] > 0):
        if(VisitedCells[robotInfo[1]][robotInfo[0]-1] == 0):
            west = True

    if(robotInfo[0] < 3):
        print(VisitedCells[robotInfo[0]-1])
        if(VisitedCells[robotInfo[1]][robotInfo[0]+1] == 0):
            east = True

    print(north, south, east, west)
    if(robotInfo[2] == 'N'):
        if(measures[1] > 16 and north):
            forward()
        elif(measures[0] > opening and west):
            #turn left
            rotate(95,0.6)
            robotInfo[2] = 'W'
            forward()
        elif(measures[2] > opening and east):
            #turn right
            rotate(-95,0.6)
            robotInfo[2] = 'E'
            forward()
        elif(south):
            #turn around
            rotate(190,1.2)
            robotInfo[2] = 'S'
            forward()

    elif(robotInfo[2] == 'E'):
        if(measures[1] > opening and east):
            forward()
        elif(measures[0] > opening and north):
            #turn left
            rotate(95,0.6)
            robotInfo[2] = 'N'
            forward()
        elif(measures[0] > opening and south):
            #turn right
            rotate(-95,0.6)
            robotInfo[2] = 'S'
            forward()
        elif(west):
            #turn around
            rotate(190,1.2)
            robotInfo[2] = 'W'
            forward()

    elif(robotInfo[2] == 'S'):
        if(measures[1] > opening and south):
            forward()
        elif(measures[0] > opening and east):
            #turn left
            rotate(95,0.6)
            robotInfo[2] = 'E'
            forward()
        elif(measures[2] > opening and west):
            #turn right
            rotate(-95,0.6)
            robotInfo[2] = 'W'
            forward()
        elif(north):
            #turn around
            rotate(190,1.2)
            robotInfo[2] = 'N'
            forward()

    elif(robotInfo[2] == 'W'):
        if(measures[1] > opening and west):
            forward()
        elif(measures[0] > opening and south):
            #turn left
            rotate(95,0.6)
            robotInfo[2] = 'S'
            forward()
        elif(measures[0] > opening and north):
            #turn right
            rotate(-95,0.6)
            robotInfo[2] = 'N'
            forward()
        elif(east):
            #turn around
            rotate(190,1.2)
            robotInfo[2] = 'E'
            forward()
    print(robotInfo)
    return robotInfo

def rotate(degrees,seconds):
    #convert to radians
    degrees = (degrees * math.pi) / 180
    desiredSpeed = degrees/seconds
    if (abs(desiredSpeed) > motorControl.MAX_IPS_W):
        print("Impossible speed")
    
    motorControl.setSpeedsVW(0, desiredSpeed)

    start = time.monotonic()
    while time.monotonic() - start < seconds:
        pass
    motorControl.setSpeedsIPS(0,0)