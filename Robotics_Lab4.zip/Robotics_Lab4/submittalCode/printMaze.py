
#Maze format: maze is a 9x9 map of the maze, cellInfo is a 4x4 list of cells with the info for each cell in the related cell.


def display(maze, cellInfo):
    i = 0
    j = 0
    x=0
    y=0
    while j < 9:
        while i < 9:
            # print(i,j, end='')
            if (j%2 == 0 and i%2 != 0): #Horizontal wall lines when j is even and i is odd.
                if maze[j][i] == 'X' :#Wall
                    print("----------", end='')
                else:
                    print("          ", end='')
            elif (i%2 == 0 and j%2 != 0): #Vertical wall lines when j is odd and i is even.
                if maze[j][i] == 'X' :#Wall
                    print("|", end='')
                else:
                    print(" ", end='')
            else:
                if maze[j][i] == 'O':
                    print("{:10.3}".format(float(cellInfo[y][x])), end='')
                    x += 1
                    if(x==4):
                        y+=1

                else:
                    print("·", end='')
            i += 1
        print(" ")
        j += 1
        x=0
        i=0

def multiDisplay(maze, cellInfo0, cellInfo1, cellInfo2):
        i = 0
        j = 0
        x=0
        y=-1
        temp = 0
 
        while j < 9:
            if(j%2 == 1):
                y+=1
            while temp < 3:
                while i < 9:
                    # print(i,j, end='')
                    if (j%2 == 0 and i%2 != 0): #Horizontal wall lines when j is even and i is odd.
                        if maze[j][i] == 'X' :#Wall
                            print("----------", end='')
                        else:
                            print("          ", end='')
                    elif (i%2 == 0 and j%2 != 0): #Vertical wall lines when j is odd and i is even.
                        if maze[j][i] == 'X' :#Wall
                            print("|", end='')
                        else:
                            print(" ", end='')
                    else:
                        if maze[j][i] == 'O':
                            if(temp == 0):
                                cellInfo = cellInfo0
                            elif(temp == 1):
                                cellInfo = cellInfo1
                            else:
                                cellInfo = cellInfo2

                            print("{:10.3}".format(float(cellInfo[y][x])), end='')
                            x += 1
                        else:
                            print("·", end='')
                    i += 1
                temp += 1
                i=0
                x=0
            print(" ")
            j += 1
            x=0
            temp = 0
            i=0
