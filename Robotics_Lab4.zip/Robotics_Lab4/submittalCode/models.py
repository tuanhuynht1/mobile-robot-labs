import sensors
import math
import copy
import triangulation

def loc(particleMap, robotInfo):
    particleMax = 9
    i = 0
    j = 0
    x = robotInfo[0]
    y = robotInfo[1]
    while j < 4:
        while i < 4:
            if particleMap[j][i] > particleMax:
                particleMax = particleMap[j][i]
                x=i
                y=j
            i += 1
        i = 0
        j+= 1
    robotInfo[0] = x
    robotInfo[1] = y
    return robotInfo

def measurementModel(mazeMap,particleMap,robotInfo):
    correctReading = 0.85
    incorrectReading = 0.15
    opening = 10
    x=0
    y=0
    n=0
    frontMeasures = []
    leftMeasures = []
    rightMeasures = []
    while n < 5:
        leftMeasures.append(sensors.getLeftDistance())
        rightMeasures.append(sensors.getRightDistance())
        frontMeasures.append(sensors.getFrontDistance())
        n+=1
    leftMeasures.sort(reverse=True)
    rightMeasures.sort(reverse=True)
    frontMeasures.sort(reverse=True)
    measures = [leftMeasures[0], frontMeasures[0], rightMeasures[0]]
    print("Measures " + str(measures))
    print("Robot Info " + str(robotInfo))
    model = []
    while y < 4:
        row = []
        while x < 4:

            prob = 1
            i = 2*x + 1
            j = 2*y + 1
            if(robotInfo[2] == 'N'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j-1][i] == '.')or(measures[1] <= opening and mazeMap[j-1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j][i-1] == '.')or(measures[0] <= opening and mazeMap[j][i-1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j][i+1] == '.')or(measures[2] <= opening and mazeMap[j][i+1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
            
            elif(robotInfo[2] == 'E'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j][i+1] == '.')or(measures[1] <= opening and mazeMap[j][i+1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j-1][i] == '.')or(measures[0] <= opening and mazeMap[j-1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j+1][i] == '.')or(measures[2] <= opening and mazeMap[j+1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]

            if(robotInfo[2] == 'S'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j+1][i] == '.')or(measures[1] <= opening and mazeMap[j+1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j][i+1] == '.')or(measures[0] <= opening and mazeMap[j][i+1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j][i-1] == '.')or(measures[2] <= opening and mazeMap[j][i-1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
            
            elif(robotInfo[2] == 'W'):
                #front sensor comparison
                if((measures[1] > opening and mazeMap[j][i-1] == '.')or(measures[1] <= opening and mazeMap[j][i-1] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #left sensor comparison
                if((measures[0] > opening and mazeMap[j+1][i] == '.')or(measures[0] <= opening and mazeMap[j+1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
                #right sensor comparison
                if((measures[2] > opening and mazeMap[j-1][i] == '.')or(measures[2] <= opening and mazeMap[j-1][i] == 'X')):
                    prob *= correctReading * particleMap[y][x]
                else:
                    prob *= incorrectReading * particleMap[y][x]
            row.append(prob)
            x += 1
        model.append(row)
        y+=1
        x = 0

    x=0
    y=0
    return model

def resample(measureProbabilities, particleNumber):
    #process: find highes probability locations, place particles based on probability, move to next highest, etc. until out of particles.
    maxUnusedProb = 0
    unusedParticles = particleNumber
    particleMap = [
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 0.0],
    ]
    i = 0
    j = 0
    while unusedParticles >0:
        i = 0
        j = 0
        while j < 4:
            while i < 4:
                if measureProbabilities[j][i] > maxUnusedProb:
                    maxUnusedProb = measureProbabilities[j][i]
                i += 1
            i = 0
            j+= 1
        
        i=0
        j=0


        while j < 4:
            while i < 4:
                if measureProbabilities[j][i] == maxUnusedProb:
                    if (round(measureProbabilities[j][i] * particleNumber) >=1 ):
                        p = float(round(measureProbabilities[j][i] * particleNumber))
                    else:
                        p = 1.0
                    particleMap[j][i] = p
                    unusedParticles -= p
                    measureProbabilities[j][i] = 0
                if unusedParticles == 0:
                    return particleMap
                i += 1
            i = 0
            j+= 1
        maxUnusedProb = 0
    return particleMap
        
def motionModel(mazeMap, particleMap, robotInfo):
    
    correctMovement = 0.9
    incorrectMovement = 0.1

    x=0
    y=0
    
    model = copy.deepcopy(particleMap)
    #print("Forward Itteration ----------------------------------------------------")
    while y < 4:
        while x < 4:

            # i and j are the mazeMap translated version of the particle map
            i = 2*x + 1
            j = 2*y + 1

            if(robotInfo[2] == 'N'):
                #print("Move particles North")
                if (mazeMap[j-1][i] == '.'):
                    model[y-1][x] = particleMap[y][x] + particleMap[y-1][x]
                    model[y][x] -= particleMap[y][x]
                    particleMap[y][x] = 0.0
            
            if(robotInfo[2] == 'E'):
                #print("Move particles East")
                if (mazeMap[j][i+1] == '.'):
                    model[y][x+1] = particleMap[y][x] + particleMap[y][x+1]
                    model[y][x] -= particleMap[y][x]
                    particleMap[y][x] = 0.0

            if(robotInfo[2] == 'S'):
                #print("Move particles South")
                if (mazeMap[j+1][i] == '.' ):
                    model[y+1][x] = particleMap[y][x] + particleMap[y+1][x]
                    model[y][x] -= particleMap[y][x]
                    particleMap[y][x] = 0.0

            if(robotInfo[2] == 'W'):
                #print("Move particles West")
                if (mazeMap[j][i-1] == '.'):
                    model[y][x-1] = particleMap[y][x] + particleMap[y][x-1]
                    model[y][x] -= particleMap[y][x]
                    particleMap[y][x] = 0.0
            x += 1
        y+=1
        x = 0

    # else:
    #     x=3
    #     y=3
    #     print("reverse itteration --------------------------------")
    #     while y >= 0:
    #         while x >= 0:
                
    #             # i and j are the mazeMap translated version of the particle map
    #             i = 2*x + 1
    #             j = 2*y + 1

    #             if(robotInfo[2] == 'N'):
    #                 print("Move particles North")
    #                 if (mazeMap[j-1][i] == '.'):
    #                     model[y-1][x] = particleMap[y][x] + particleMap[y-1][x]
    #                     particleMap[y][x] = 0.0
                
    #             if(robotInfo[2] == 'E'):
    #                 print("Move particles East")
    #                 if (mazeMap[j][i+1] == '.'):
    #                     model[y][x+1] = particleMap[y][x] + particleMap[y][x+1]
    #                     particleMap[y][x] = 0.0

    #             if(robotInfo[2] == 'S'):
    #                 print("Move particles South")
    #                 if (mazeMap[j+1][i] == '.'):
    #                     model[y+1][x] = particleMap[y][x] + particleMap[y+1][x]
    #                     particleMap[y][x] = 0.0

    #             if(robotInfo[2] == 'W'):
    #                 print("Move particles West")
    #                 if (mazeMap[j][i-1] == '.'):
    #                     model[y][x-1] = particleMap[y][x] + particleMap[y][x-1]
    #                     particleMap[y][x] = 0.0
    #             x -= 1
    #     y-=1
    #     x = 3
    x=0
    y=0
    return model

def normalize(probabilityMap):
    normalizedMap = probabilityMap
    total = 0.0
    i=0
    j=0

    while j < 4:
        while i < 4:
            total += probabilityMap[j][i]
            i+=1
        j += 1
        i = 0
    i = 0
    j = 0

    while j < 4:
        while i < 4:
            normalizedMap[j][i] = probabilityMap[j][i]/total
            i += 1
        j += 1
        i = 0
    
    return normalizedMap

def triangulationMeasurementModel(mazeMap,particleMap,robotInfo):
    correctReading = 0.7
    incorrectReading = 0.3
    estLoc=[3,3]
    x=0
    y=0
    n=0
    estX,estY = trangulation.run()
    estLoc[0] = math.round(estX/18)
    estLoc[1] = math.round(estY/18)
    print("Measures " + str(estX) + str(estY))
    print("Robot Info " + str(robotInfo))
    model = []
    while y < 4:
        row = []
        while x < 4:

            prob = 1
            if(estLoc[0] == x):
                prob *= correctReading
            else:
                prob *= incorrectReading
            if(estLoc[1] == y):
                prob *= correctReading
            else:
                prob *= incorrectReading
            row.append(prob)
            x += 1
        model.append(row)
        y+=1
        x = 0

    x=0
    y=0
    return model