import encoders
import motorControl
import sensors
import math
import time

# keep the robot centered horizontally in cell as it moves.
def centeredSpeed(linearVelocity):
    desired = 7.5
    opening = 12
    Kp = 1.5
    tollerance = 0.001
    ldist = sensors.getLeftDistance()
    rdist = sensors.getRightDistance()
    
    #neither wall is seen, can't center
    if(ldist > 20 and rdist > 20):
        return linearVelocity, linearVelocity
    
    #if only right wall is seen
    elif(ldist > opening and rdist <=opening):
        #too far from right wall
        if(rdist - desired > 0):
            error = min(rdist-desired, Kp)
            if linearVelocity > 0:
                return linearVelocity, linearVelocity - error
            else:
                return linearVelocity - error, linearVelocity
        
        #too close to right wall
        elif(rdist - desired < 0):
            error = min(desired-rdist, Kp)
            if linearVelocity > 0:
                return linearVelocity - error, linearVelocity
            else:
                return linearVelocity, linearVelocity - error
    
    #if only left wall is seen
    elif(rdist > opening and ldist <= opening):
        #too far from left wall
        if(ldist - desired > 0):
            error = min(ldist-desired, Kp)
            if linearVelocity > 0:
                return linearVelocity-error, linearVelocity
            else:
                return linearVelocity, linearVelocity-error
        
        #too close to left wall
        elif(desired - ldist < 0):
            error = min(desired-ldist, Kp)
            if linearVelocity > 0:
                return linearVelocity, linearVelocity - error
            else:
                return linearVelocity - error, linearVelocity
    
    #both walls are seen
    else:
        if (ldist-rdist > tollerance):
            error = min(ldist - rdist, Kp)
            #left wheel should slow down to move closer to the left
            if linearVelocity > 0:    
                return linearVelocity - error , linearVelocity
            else:
                return linearVelocity, linearVelocity - error

        elif(ldist-rdist < -1*tollerance):
            error = min(rdist - ldist, Kp)
            #left wheel should slow down to move closer to the left
            if linearVelocity > 0:
                return linearVelocity, linearVelocity - error
            else:
                return linearVelocity - error , linearVelocity
        else:
            return linearVelocity, linearVelocity
    return linearVelocity, linearVelocity
def forward():
    
    x = 18
    y = 3
    desiredSpeed = x/y
    desiredDistance = 7

    if (abs(desiredSpeed) > motorControl.MAX_IPS):
        print("Inconceivable speed")
        sys.exit()

    totalTicks = (1/motorControl.IPT) * abs(x)
    lspeed, rspeed = centeredSpeed(desiredSpeed)
    motorControl.setSpeedsIPS(lspeed, rspeed)
    encoders.resetCount()


    while (encoders.getCounts()[0] < totalTicks and sensors.getFrontDistance() > desiredDistance):
        speeds = centeredSpeed(desiredSpeed)
        motorControl.setSpeedsIPS(speeds[0], speeds[1])
    
    motorControl.stop()



def saturateLinear(velocity):
    if(velocity > motorControl.MAX_IPS):
        velocity = motorControl.MAX_IPS
    elif(velocity < -1*motorControl.MAX_IPS):
        velocity = -1*motorControl.MAX_IPS
    return velocity

def linearDesiredVelocity(desiredDist,Kp):
    # e(t) = r(t) - y(t)
    error = desiredDist - sensors.getFrontDistance()
    error = error * -1 # adjust velocity based on robot's perspective

    # u(t) = Kp * e(t)
    velocity = Kp * error

    #u_r(t) = fsat(u(t))
    velocity = saturateLinear(velocity)
    
    # motorControl.setSpeedsIPS(velocity,velocity)
    return velocity

def explore(robotInfo, mazeMap, VisitedCells):
    opening = 10
    x = robotInfo[0]
    y = robotInfo[1]
    i = 2*x + 1
    j = 2*y + 1
    #check if the robot should move in a direction

    north = False
    south = False
    east = False
    west = False
    frontMeasures = []
    leftMeasures = []
    rightMeasures = []
    n=0
    while n < 5:
        leftMeasures.append(sensors.getLeftDistance())
        rightMeasures.append(sensors.getRightDistance())
        frontMeasures.append(sensors.getFrontDistance())
        n+=1
    leftMeasures.sort(reverse=True)
    rightMeasures.sort(reverse=True)
    frontMeasures.sort(reverse=True)
    measures = [leftMeasures[0], frontMeasures[0], rightMeasures[0]]
    visitedMin = 99
    #Calculate the which cells have been explored the least.
    #First find the minimum visits of adjacent accessable cells
    if(robotInfo[1] > 0):
        if(VisitedCells[robotInfo[1]-1][robotInfo[0]] < visitedMin and mazeMap[j-1][i] != 'X'):
            visitedMin = VisitedCells[robotInfo[1]-1][robotInfo[0]]

    if(robotInfo[1] < 3):
        if(VisitedCells[robotInfo[1]+1][robotInfo[0]] < visitedMin and mazeMap[j+1][i] != 'X'):
            visitedMin = VisitedCells[robotInfo[1]+1][robotInfo[0]]

    if(robotInfo[0] > 0):
        if(VisitedCells[robotInfo[1]][robotInfo[0]-1] < visitedMin and mazeMap[j][i-1] != 'X'):
            visitedMin = VisitedCells[robotInfo[1]][robotInfo[0]-1]

    if(robotInfo[0] < 3):
        if(VisitedCells[robotInfo[1]][robotInfo[0]+1] < visitedMin and mazeMap[j][i+1] != 'X'):
            visitedMin = VisitedCells[robotInfo[1]][robotInfo[0]+1]
    #Then mark the dircetions with the least number of visits
    if(robotInfo[1] > 0):
        if(VisitedCells[robotInfo[1]-1][robotInfo[0]] == visitedMin and mazeMap[j-1][i] != 'X'):
            north = True

    if(robotInfo[1] < 3):
        if(VisitedCells[robotInfo[1]+1][robotInfo[0]] == visitedMin and mazeMap[j+1][i] != 'X'):
            south = True

    if(robotInfo[0] > 0):
        if(VisitedCells[robotInfo[1]][robotInfo[0]-1] == visitedMin and mazeMap[j][i-1] != 'X'):
            west = True

    if(robotInfo[0] < 3):
        if(VisitedCells[robotInfo[1]][robotInfo[0]+1] == visitedMin and mazeMap[j][i+1] != 'X'):
            east = True
    

    if(robotInfo[2] == 'N'):
        if(measures[1] > opening and north):
            
            forward()
            robotInfo[1] -= 1
        elif(measures[0] > opening and west):
            #turn left
            rotate(90,0.6)
            robotInfo[2] = 'W'
            forward()
            robotInfo[0] -= 1
        elif(measures[2] > opening and east):
            #turn right
            rotate(-90,0.6)
            robotInfo[2] = 'E'
            forward()
            robotInfo[0] += 1
        elif(south):
            #turn around
            rotate(180,1.2)
            robotInfo[2] = 'S'
            forward()
            robotInfo[1] += 1
        else:
            print("ERROR")

    elif(robotInfo[2] == 'E'):
        if(measures[1] > opening and east):
            
            forward()
            robotInfo[0] += 1
        elif(measures[0] > opening and north):
            #turn left
            rotate(95,0.6)
            robotInfo[2] = 'N'
            forward()
            robotInfo[1] -= 1
        elif(measures[2] > opening and south):
            #turn right
            rotate(-95,0.6)
            robotInfo[2] = 'S'
            forward()
            robotInfo[1] += 1
        elif(west):
            #turn around
            rotate(190,1.2)
            robotInfo[2] = 'W'
            forward()
            robotInfo[0] -= 1
        else:
            print("ERROR")

    elif(robotInfo[2] == 'S'):
        if(measures[1] > opening and south):
            
            forward()
            robotInfo[1] += 1
        elif(measures[0] > opening and east):
            #turn left
            rotate(95,0.6)
            robotInfo[2] = 'E'
            forward()
            robotInfo[0] += 1
        elif(measures[2] > opening and west):
            #turn right
            rotate(-95,0.6)
            robotInfo[2] = 'W'
            forward()
            robotInfo[0] -= 1
        elif(north):
            #turn around
            rotate(190,1.2)
            robotInfo[2] = 'N'
            forward()
            robotInfo[1] -= 1
        else:
            print("ERROR")

    elif(robotInfo[2] == 'W'):
        if(measures[1] > opening and west):
            
            forward()
            robotInfo[0] -= 1
        elif(measures[0] > opening and south):
            #turn left
            
            rotate(95,0.6)
            robotInfo[2] = 'S'
            forward()
            robotInfo[1] += 1
        elif(measures[2] > opening and north):
            #turn right
            
            rotate(-95,0.6)
            robotInfo[2] = 'N'
            forward()
            robotInfo[1] -= 1
        elif(east):
            #turn around
            rotate(190,1.2)
            robotInfo[2] = 'E'
            forward()
            robotInfo[0] += 1
        else:
            print("ERROR")

    return robotInfo

def rotate(degrees,seconds):
    #convert to radians
    degrees = (degrees * math.pi) / 180
    desiredSpeed = degrees/seconds
    if (abs(desiredSpeed) > motorControl.MAX_IPS_W):
        print("Impossible speed")
    
    motorControl.setSpeedsVW(0, desiredSpeed)

    start = time.monotonic()
    while time.monotonic() - start < seconds:
        pass
    motorControl.setSpeedsIPS(0,0)