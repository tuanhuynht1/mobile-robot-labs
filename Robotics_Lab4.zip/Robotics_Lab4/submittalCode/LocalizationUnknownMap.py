import encoders
import motorControl
import sensors
import printMaze
import models

import signal
import os
import time
import math

import copy

import motion



def run():
    #X's represent walls, .'s are openings and O's are cells
    mazeMap = [ 
        ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', '.', '.', '.', '.', '.', '.', '.', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', '.', '.', '.', '.', '.', '.', '.', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', '.', '.', '.', '.', '.', '.', '.', 'X'],
        ['X', 'O', '.', 'O', '.', 'O', '.', 'O', 'X'],
        ['X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'],
    ]

    
    cellID = [
        [1.0, 2.0, 3.0, 4.0],
        [5.0, 6.0, 7.0, 8.0],
        [9.0, 10.0, 11.0, 12.0],
        [13.0, 14.0, 15.0, 16.0],
    ]
    print("Maze Startup")
    printMaze.display(mazeMap, cellID)

    #initialize
    particles = [
        [1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1],
        [1, 1, 1, 1],
    ]
    # particles = [
    #     [16, 0, 0, 0],
    #     [0, 0, 0, 0],
    #     [0, 0, 0, 0],
    #     [0, 0, 0, 0],
    # ]
    #map of number of times a cell has been visited visited cells
    VisitedCells = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
    ]
    cellsVisitedCount = 0
    robotInfo = [3,3,'N']
    robotCell = robotInfo[1]*4 + robotInfo[0]
    print(" Initial Maze Setup")
    printMaze.display(mazeMap, cellID)
    print("Robot Info: " + str(robotCell) + " " + robotInfo[2])
    while cellsVisitedCount < 16:

        updateMap(robotInfo, mazeMap)

        

        print(robotInfo)
        # particles = [
        # [1, 1, 1, 1],
        # [1, 1, 1, 1],
        # [1, 1, 1, 1],
        # [1, 1, 1, 1],
        # ]
        #apply measuremnet model
        mM = models.measurementModel(mazeMap, particles, robotInfo)

        normMap = models.normalize(mM)
        #print("Normalized Map")
        #printMaze.display(mazeMap, normMap)
        #resample
        particles = models.resample(normMap, 16)
        robotInfo = models.loc(particles, robotInfo)

        if(VisitedCells[robotInfo[1]][robotInfo[0]] == 0):
            cellsVisitedCount +=1
        
        VisitedCells[robotInfo[1]][robotInfo[0]] += 1
        print("                Measurement Model                                Normalized Measures                                Particles")
        printMaze.multiDisplay(mazeMap, mM, normMap, particles)

        #motion
        robotInfo = motion.explore(robotInfo, mazeMap, VisitedCells)
        #apply motion model
        particles = models.motionModel(mazeMap,particles, robotInfo)
        print("                Cells Visited                                Updated Particles                                Cells")
        printMaze.multiDisplay(mazeMap, VisitedCells, particles, cellID)
        robotCell = robotInfo[1]*4 + robotInfo[0]
        print("Robot Info: " + str(robotCell) + robotInfo[2])
        if(cellsVisitedCount == 15):
            print("So long and thanks for all the fish")
            cellsVisitedCount += 1
        


def updateMap(robotInfo, mazeMap):
    opening = 10
    measures = sensors.getDistances()
    # i and j are the mazeMap translated version of the particle map
    x = robotInfo[0]
    y = robotInfo[1]
    i = 2*x + 1
    j = 2*y + 1
    if(robotInfo[2]=='N'):
        if(measures[1] < opening):
            mazeMap[j-1][i] ='X'
        if(measures[0] < opening):
            mazeMap[j][i-1] ='X'
        if(measures[2] < opening):
            mazeMap[j][i+1] ='X'
    elif(robotInfo[2]=='S'):
        if(measures[1] < opening):
            mazeMap[j+1][i] ='X'
        if(measures[0] < opening):
            mazeMap[j][i+1] ='X'
        if(measures[2] < opening):
            mazeMap[j][i-1] ='X'
    elif(robotInfo[2]=='E'):
        if(measures[1] < opening):
            mazeMap[j][i+1] ='X'
        if(measures[0] < opening):
            mazeMap[j-1][i] ='X'
        if(measures[2] < opening):
            mazeMap[j+1][i] ='X'
    elif(robotInfo[2]=='W'):
        if(measures[1] < opening):
            mazeMap[j][i-1] ='X'
        if(measures[0] < opening):
            mazeMap[j+1][i] ='X'
        if(measures[2] < opening):
            mazeMap[j-1][i] ='X'



