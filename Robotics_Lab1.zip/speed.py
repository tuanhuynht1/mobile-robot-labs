import time
import signal
import encoders
import motorControl
import math
import csv
import json

# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    exit()
signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+C signal interrupt
encoders.initEncoder()


# C.1.1 Task 1.12 - PWM
# In a single graph use the encoders to plot the speed of both wheels (in revolutions per second) vs
# the input to the implemented function setSpeedsPWM. Measure the speeds of the wheels from
# 1.3 ms to 1.7 ms in increments of 0.01. Provide the plot in the report.
# Things to think about:
# • How similar do both servos react to the same input? Does the difference look like random
# noise? If not, what could be causing the difference? Why is it a good idea to use software
# calibration?
# • Before measuring the speed, you should allow some time for the servo to stabilize its speed.
# Also, you should use the average speed over a time window instead of the instantaneous
# speed.

# calibrate speed and plot chart onto csv file
motorControl.calibrateSpeeds() #saved in motorControl.chart and in speedChart.json

# print("Calibrate speed for charting")
# # create csv file
csv_file = "speedChart.csv"
with open(csv_file,'w') as f:
    for k in sorted(motorControl.chart.keys()):
        f.write("%s,%s,%s\n"%(k,motorControl.chart[k][0],motorControl.chart[k][1]))

# C.1.2 Task 1.2 – Load
# In two separate graphs (one graph per wheel) use the encoders to measure the instantaneous
# speed5 of each servo (in revolutions per second) vs time. Measure the speed of the each wheel
# using a constant PWM on both wheels of 1.6 ms, and compare in each plot the following loads:
# 1. Servo speed without any load, i.e. no friction on the servo
# 2. Servo speed on carpet
# 3. Servo speed on floor
# Take measurements every 30 ms for approximately 10 seconds. Before taking any measurements
# wait 1 second to allow the motor to reach the desired speed. In the y axis, only include the
# effective range, that is, for example, if you only get values from 0.6 to 0.7, the range in the y axis
# should be the same, it should NOT be from 0 to 0.7. Provide the plot in the report.
# Aspects to think about:
# • Is this value constant?
# • If not, does the plot look random or does it have a pattern? Think of reasons that might
# explain the behavior.

# chart = {}
# filename = input ("Filename: ")
# motorControl.setSpeedsPWM(1.6,1.6)

# #1 second buffer
# time.sleep(1)

# #10 second measurement
# total = time.monotonic()
# ms = 30
# while time.monotonic() - total < 10:
#     timer = time.monotonic()
#     while time.monotonic() - timer < .03:
#         pass
#     speeds = encoders.getSpeeds()
#     chart[ms] = speeds
#     ms += 30

# motorControl.stop()

# csv_file = filename
# with open(csv_file,'w') as f:
#     for k in sorted(chart.keys()):
#         f.write("%s,%s,%s\n"%(k,chart[k][0],chart[k][1]))
