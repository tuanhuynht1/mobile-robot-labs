import motorControl
import encoders
import sys
import signal
import json
import time

# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    exit()

signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+C signal interrupt
encoders.initEncoder()

#read json
with open(motorControl.CHART) as loadfile:
    json_chart = json.load(loadfile)
#convert keys to float
for sk in json_chart.keys():
    motorControl.chart[float(sk)] = json_chart[sk]

# C.2 Task 2 - Distance
# Implement the program ‘Distance.py’. The robot should move in a straight line for “X” inches.
# The robot should complete the movement in “Y” seconds. The robot should stop based on
# encoder readings (distance traversed), not on the time past. “X” and “Y” are parameters provided
# through terminal interfacing. The program should work for any values “X” and “Y” for which it
# is possible to complete the movement on the given time. If the robot can’t complete the
# movement in the given amount of time, instead of moving forward, the program should display
# an appropriate message. The program should read and print from the encoders the instantaneous 
# speed6 of each of the two servos (in revolutions per second). Measurements should be taken
# every 30 ms for approximately 10 seconds.
# During task presentation, the TA will assign different values for “X” and “Y”.


def travel(x,y):
    desiredSpeed = x/y
    if (abs(desiredSpeed) > motorControl.MAX_IPS):
        print("Impossible speed")
        sys.exit()
    print(desiredSpeed/motorControl.CIR)

    totalTicks = (1/motorControl.IPT) * abs(x)
    motorControl.setSpeedsIPS(desiredSpeed,desiredSpeed)
    encoders.resetCount()

    flag = False
    start = time.monotonic()
    while time.monotonic() - start < 10:
        sample = time.monotonic()
        while time.monotonic() - sample <= .03:
            if (encoders.getCounts()[0] >= totalTicks):
                motorControl.stop()
                flag = True
                break
        
        if(flag != True):
            print(encoders.getSpeeds())
        
    while encoders.getCounts()[0] < totalTicks:
        pass   

#users input
distance = float(input("Distance in inches: "))
seconds = float(input("Time in seconds: "))
travel(distance,seconds)
motorControl.stop()

