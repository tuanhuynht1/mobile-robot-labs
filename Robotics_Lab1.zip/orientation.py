import motorControl
import encoders
import sys
import signal
import json
import time
import math

# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    exit()

signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+C signal interrupt
encoders.initEncoder()

#read json
with open(motorControl.CHART) as loadfile:
    json_chart = json.load(loadfile)
#convert keys to float
for sk in json_chart.keys():
    motorControl.chart[float(sk)] = json_chart[sk]


# C.3 Task 3 – Orientation
# Implement the program ‘Orientation.py’. The robot should rotate in “X” degrees and then stop.
# The robot should complete the movement in “Y” seconds. The robot should stop based on
# encoder readings (degrees rotated), not on time past. “X” and “Y” are parameters provided
# through terminal interfacing. The program should work for any value “X” and “Y”, including
# negative values, for which it is possible to complete the movement on the given time. If the robot
# can’t complete the movement in the given amount of time, instead of moving forward, the
# program should display an appropriate message. The program should read and print from the
# encoders the angular speed7 of rotation of each of the two servos (in revolutions per second).
# Measurements should be taken every 30 ms for as long as the rotation takes place.
# During task presentation, the TA will assign different values for “X” and “Y”.

def rotate(degrees,seconds):
    #convert to radians
    degrees = (degrees * math.pi) / 180
    desiredSpeed = degrees/seconds
    if (abs(desiredSpeed) > motorControl.MAX_IPS_W):
        print("Impossible speed")
        sys.exit()
    print(desiredSpeed/motorControl.CIR)

    motorControl.setSpeedsVW(0, desiredSpeed)

    start = time.monotonic()
    ticker = start
    while time.monotonic() - start < seconds:
        sample = time.monotonic()
        if(sample - ticker >= .03):
            ticker = time.monotonic()
            print(encoders.getSpeeds())
    motorControl.stop()
    


#users input
x = float(input("Degrees in degrees: "))
y = float(input("Time in seconds: "))

rotate(x,y)
    

