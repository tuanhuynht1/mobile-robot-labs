import motorControl
import encoders
import sys
import signal
import json
import time
import math

# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    exit()

signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+C signal interrupt
encoders.initEncoder()

#read json
with open(motorControl.CHART) as loadfile:
    json_chart = json.load(loadfile)
#convert keys to float
for sk in json_chart.keys():
    motorControl.chart[float(sk)] = json_chart[sk]

def rotate(degrees,seconds):
    #convert to radians
    degrees = (degrees * math.pi) / 180
    desiredSpeed = degrees/seconds
    if (abs(desiredSpeed) > motorControl.MAX_IPS_W):
        print("Impossible speed")
        sys.exit()
    print(desiredSpeed/motorControl.CIR)

    motorControl.setSpeedsVW(0, desiredSpeed)

    start = time.monotonic()
    ticker = start
    while time.monotonic() - start < seconds:
        sample = time.monotonic()
        if(sample - ticker >= .03):
            ticker = time.monotonic()
            print(encoders.getSpeeds())
    motorControl.stop()

# C.5 Task 5 - Circle
# Implement the program ‘Circle.py’. The program should make the robot move following a
# semicircle of radius “R”, as shown in Figure 1. The robot should start from (-R,0) and wait until
# given a command on the terminal. When the terminal command is issued, the robot should
# follow the path in a clockwise movement. After completing the semicircle, the robot should stop
# and wait for another command, and then rotate on its vertical axis and perform the same path
# back but in a counterclockwise manner. The whole movement must be completed in “Y” seconds 
# moving at the same constant speed for both halves. The robot should stop based on encoder
# readings (distance traversed), and not based on a given time.
# The program must work for any values of “R” and “Y”, provided through user input. If the
# motion cannot be completed in the given time, after issuing the command for the first time, the
# robot should refuse and display the appropriate message.
# Observe that, independently of the trajectory, the robot moves by fixing the speeds of the wheels
# for a given amount of time.
# During the task presentation, the TA will assign different values for “R” and “Y

r = float(input("Radius in inches: "))
t = float(input("Time in seconds: "))/2

#omega is half a circle in t seconds
w = math.pi / t

vl = w * (r + (motorControl.DIA_R))
vr =  w * (r - (motorControl.DIA_R))

if (abs(vl) > motorControl.MAX_IPS or abs(vr) > motorControl.MAX_IPS):
    print("Infeasible")
    sys.exit()

totalTicks = (1/motorControl.IPT) * abs((r+motorControl.DIA_R/2)*math.pi)

encoders.resetCount()
motorControl.setSpeedsIPS(vl,vr)
while encoders.getCounts()[0] <= totalTicks and encoders.getCounts()[1] <= totalTicks:
    pass

rotate(180,1)

encoders.resetCount()
motorControl.setSpeedsIPS(vr,vl)
while encoders.getCounts()[0] <= totalTicks and encoders.getCounts()[1] <= totalTicks:
    pass


motorControl.stop()