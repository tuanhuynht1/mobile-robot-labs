import motorControl
import encoders
import sys
import signal
import json
import time
import math
# import orientation
# import distance

# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    exit()

signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+C signal interrupt
encoders.initEncoder()

#read json
with open(motorControl.CHART) as loadfile:
    json_chart = json.load(loadfile)
#convert keys to float
for sk in json_chart.keys():
    motorControl.chart[float(sk)] = json_chart[sk]

# C.4 Task 4 - Rectangle
# Implement the program ‘Rectangle.py’. The program should make the robot move following a
# rectangle with height “H” and width “W”, as shown in Figure 1. The robot should start from the
# bottom corner (-W/2,-H/2) and wait until given a command on the terminal. When the terminal
# command is issued, the robot should follow the path in a clockwise movement. After completing
# the rectangle, the robot should stop. The whole movement must be completed in “Y” seconds
# moving at the same constant speed. The robot should stop based on encoder readings (distance
# traversed), and not based on a given time.
# The program must work for any values of “H”, “W” and “Y”, provided through user input. If the
# motion cannot be completed in the given time, after issuing the command for the first time, the
# robot should refuse and display the appropriate message.
# Observe that, independently of the trajectory, the robot moves by fixing the speeds of the wheels
# for a given amount of time.
# During the task presentation, the TA will assign different values for “H”, “W” and “Y”.


def rotate(degrees,seconds):
    #convert to radians
    degrees = (degrees * math.pi) / 180
    desiredSpeed = degrees/seconds
    if (abs(desiredSpeed) > motorControl.MAX_IPS_W):
        print("Impossible speed")
        sys.exit()
    print(desiredSpeed/motorControl.CIR)
    
    motorControl.setSpeedsVW(0, desiredSpeed)

    start = time.monotonic()
    ticker = start
    while time.monotonic() - start < seconds:
        pass

def travel(x,y):
    desiredSpeed = x/y
    if (abs(desiredSpeed) > motorControl.MAX_IPS):
        print("Impossible speed")
        sys.exit()
    print(desiredSpeed/motorControl.CIR)

    totalTicks = (1/motorControl.IPT) * abs(x)
    motorControl.setSpeedsIPS(desiredSpeed,desiredSpeed)
    encoders.resetCount()

    while encoders.getCounts()[0] <= totalTicks:
        pass


height = float(input("H: "))
width = float(input("W: "))
seconds = float(input("Y: "))

desired_time = seconds-2
hTime = (height/(width + height) * desired_time)/2
wTime = (width/(width + height) * desired_time)/2

#left side
travel(height,hTime)
#top left corner
rotate(-90,0.5)
#top side
travel(width,wTime)
#top right corner
rotate(-90,0.5)
#right side
travel(height,hTime)
#bottom left corner
rotate(-90,0.5)
#bottom side
travel(width,wTime)
#bottom left corner
rotate(-90,0.5)

motorControl.stop()




