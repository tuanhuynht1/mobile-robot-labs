# libraries
import time
import Adafruit_PCA9685
import signal
import math
import RPi.GPIO as GPIO

# Pins that the encoders are connected to
LENCODER = 17
RENCODER = 18

#Counters for encoders
lCount = 0
rCount = 0

# Timer for Speeds
lT = 0
rT = 0
lSpeed = 0
rSpeed = 0

# Wheel Constants
TICKS = 32
RPT = 1 / TICKS

# Resets both encoders to 0.
def resetCount():
    global lCount
    global rCount
    lCount = 0
    rCount = 0
# Get the count of both encoders
def getCounts():
    global lCount
    global rCount
    return lCount, rCount

# This function is called when the left encoder detects a rising edge signal.
def onLeftEncode(pin):
    global lCount
    global lT
    global lSpeed

    lCount += 1
    elapsed = time.monotonic() - lT
    lT = time.monotonic()
    lSpeed = RPT/elapsed

# This function is called when the right encoder detects a rising edge signal.
def onRightEncode(pin):
    global rCount
    global rT
    global rSpeed

    rCount += 1
    elapsed = time.monotonic() - rT
    rT = time.monotonic()
    rSpeed = RPT/elapsed


def getSpeeds():
    global lSpeed, rSpeed
    return lSpeed, rSpeed

# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program.
def cleanUp():
    GPIO.cleanup()
    
def initEncoder():
    
    global lT, rT

    # Set the pin numbering scheme to the numbering shown on the robot itself.
    GPIO.setmode(GPIO.BCM)

    #initialize timers for speed
    lT = time.monotonic()
    rT = lT

    # Set encoder pins as input
    # Also enable pull-up resistors on the encoder pins
    # This ensures a clean 0V and 3.3V is always outputted from the encoders.
    GPIO.setup(LENCODER, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    GPIO.setup(RENCODER, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    # Attach a rising edge interrupt to the encoder pins
    GPIO.add_event_detect(LENCODER, GPIO.RISING, onLeftEncode)
    GPIO.add_event_detect(RENCODER, GPIO.RISING, onRightEncode)

