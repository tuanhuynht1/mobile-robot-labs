import time
import encoders
import Adafruit_PCA9685
import signal
import math
import decimal
import json

# The servo hat uses its own numbering scheme within the Adafruit library.
# 0 represents the first servo, 1 for the second, and so on.
LSERVO = 1
RSERVO = 0

#PWM LIMITS
MAX_PWM = 1.7
MIN_PWM = 1.3

#chart calibration file
CHART = "speedChart.json"

# Initialize the servo hat library.
pwm = Adafruit_PCA9685.PCA9685()

# 50Hz is used for the frequency of the servos.
pwm.set_pwm_freq(50)

# Write an initial value of 1.5, which keeps the servos stopped.
# Due to how servos work, and the design of the Adafruit library, 
# the value must be divided by 20 and multiplied by 4096.
pwm.set_pwm(LSERVO, 0, math.floor(1.5 / 20 * 4096));
pwm.set_pwm(RSERVO, 0, math.floor(1.5 / 20 * 4096));

#value to increment servos
step = 0.01

#constant attributes
CIR = 8.011
DIA_R = 4.0
MAX_RPS = 0.8
MAX_IPS = MAX_RPS * CIR
MAX_IPS_W = math.pi
IPT = encoders.RPT * CIR

#speed table
chart = {}


def stop():
    # print("Stop")
    pwm.set_pwm(LSERVO, 0, 0);
    pwm.set_pwm(RSERVO, 0, 0);

def calibrateSpeeds():
    global step, chart
    i = 1.3
    while i < 1.5:
        setSpeedsPWM(i,i)
        # take 5 sample data in .5 sec intervals 
        sampleL = []
        sampleR = []
        for j in range(5):
            start = time.monotonic()
            while time.monotonic() - start < .5:
                pass
            speeds = encoders.getSpeeds()
            sampleL.append(speeds[LSERVO])
            sampleR.append(speeds[RSERVO])
        sampleL = sorted(sampleL)
        sampleR = sorted(sampleR)
        #after sorting, select the median
        chart[i] = round(sampleL[2],4) , -1*round(sampleR[2],4)
        i = round(i+step,2)

    chart[1.5] = 0,0
    i = round(1.5 + step,2)
    while i <= MAX_PWM:
        setSpeedsPWM(i,i)
        # take 5 sample data in .5 sec intervals 
        sampleL = []
        sampleR = []
        for j in range(5):
            start = time.monotonic()
            while time.monotonic() - start < .5:
                pass
            speeds = encoders.getSpeeds()
            sampleL.append(speeds[LSERVO])
            sampleR.append(speeds[RSERVO])
        sampleL = sorted(sampleL)
        sampleR = sorted(sampleR)
        #after sorting, select the median
        chart[i] = -1*round(sampleL[2],4) , round(sampleR[2],4)
        i = round(i+step,2)
    
    with open(CHART,'w') as json_file:
        json.dump(chart,json_file)

    stop()

def fullThrottle(secs):
    setSpeedsPWM(MAX_PWM,MAX_PWM)
    start = time.monotonic()
    while time.monotonic() - start < secs:
        pass
    stop()

def findPWM(rpsL,rpsR):
    global chart
    pwmL = 1.3
    pwmR = 1.3
    for pwm in chart.keys():
        if abs(chart[pwm][LSERVO] - rpsL) < abs(chart[pwmL][LSERVO]- rpsL):
            pwmL = pwm
        if abs(chart[pwm][RSERVO] - rpsR) < abs(chart[pwmR][RSERVO]- rpsR):
            pwmR = pwm
    print("findPWM:",pwmL,pwmR)
    return pwmL, pwmR

def setSpeedsPWM (pwmLeft, pwmRight):   #sets servo speed based on pwm
    #if the pwm is outside of the bounds, set it to the max or min
    if(pwmLeft > 1.7):
        pwmLeft = 1.7
    if(pwmRight > 1.7):
        pwmRight = 1.7
    if(pwmLeft < 1.3):
        pwmLeft = 1.3
    if(pwmRight < 1.3):
        pwmRight = 1.3
    
    pwm.set_pwm(LSERVO, 0, math.floor((pwmLeft) / 20 * 4096))
    pwm.set_pwm(RSERVO, 0, math.floor((pwmRight) / 20 * 4096))

def setSpeedsRPS (rpsLeft, rpsRight):
    pwmLeft, pwmRight = findPWM(rpsLeft,rpsRight)
    setSpeedsPWM(pwmLeft,pwmRight) 

def setSpeedsIPS(ipsLeft, ipsRight):
    rpsLeft = ipsLeft/CIR
    rpsRight = ipsRight/CIR
    # print("setSpeedIPS:",rpsLeft,rpsRight)

    # r = (DIA_R/2)*(ipsLeft+ipsRight)/(ipsRight-ipsLeft)
    # print("V: ",r*math.pi/4)
    # w = (ipsRight-ipsLeft)/DIA_R
    # print("W: ", w)

    setSpeedsRPS(rpsLeft,rpsRight)
    
def setSpeedsVW(v,w):
    vr = v + (DIA_R*w/2.0)
    vl = (2*v) - vr
    # print("setSpeedVW:",vl,vr)
    setSpeedsIPS(vl,vr)