import encoders
import motorControl
import sensors
# import blob
import signal
import os
import time
import faceGoal
import motionToGoal
import bug
import triangulation

# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    sensors.lSensor.stop_ranging()
    sensors.fSensor.stop_ranging()
    sensors.rSensor.stop_ranging()
    exit()

# Attach the Ctrl+C signal interrupt
signal.signal(signal.SIGINT, ctrlC) 

#clear screen after sensors initialization
os.system('clear')

#initialize speed chart 
if motorControl.setChart() ==  False:
    motorControl.calibrateSpeeds()
    motorControl.setChart()

# #initialize ThreadedWebcam object
# camera = ThreadedWebcam.ThreadedWebcam()
# camera.start() 

while True:
    #parse command
    print("-------------------------------------------Command List---------------------------------------")
    print("[c] calibrate, [q] quit, [1] task 1, [2] task 2, [3] task 3, [4] task 4, [ENTER] clear screen")
    print("----------------------------------------------------------------------------------------------\n")
    cmd = input("Command: ")
    
    #software robustness
    if not cmd:
        os.system('clear')

    elif cmd[0] == '1':
        print("\ntask 1...") 
        faceGoal.run()
        # time.sleep(2)   
        # os.system('clear')

    elif cmd[0] == '2' :
        print("\ntask 2...")
        motionToGoal.run()
        # time.sleep(2)
        # os.system('clear')

    elif cmd[0] == '3' :
        print("\ntask 3...")
        triangulation.run()
        # time.sleep(2)
        # os.system('clear')

    elif cmd[0] == '4' :
        print("\ntask 4...")
        bug.run()
        # time.sleep(2)
        # os.system('clear')

    elif cmd[0] == '.' :
        print("\ndebugging...")
        camera.read()
        # os.system('clear')

    elif cmd[0] == 'q' :
        os.system('clear')
        motorControl.stop()
        encoders.cleanUp()
        sensors.lSensor.stop_ranging()
        sensors.fSensor.stop_ranging()
        sensors.rSensor.stop_ranging()
        exit()

    elif cmd[0] == 'c':
        print("\nRecalibrating...")
        motorControl.calibrateSpeeds()
        motorControl.setChart()
        os.system('clear')
        
    else:
        os.system('clear')
        print("\nCommand not found, try again\n")

 
