import motorControl
import encoders
import sys
import signal
import json
import time
import sensors
import task1
import wallDistance as task2
import wallFollowing as task3


# This function is called when Ctrl+C is pressed.
# It's intended for properly exiting the program
def ctrlC(signum, frame):
    motorControl.stop()
    encoders.cleanUp()
    sensors.lSensor.stop_ranging()
    sensors.fSensor.stop_ranging()
    sensors.rSensor.stop_ranging()
    exit()

signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+C signal interrupt

#set chart if available
success =  motorControl.setChart() # to avoid crashing or unexpected behavior

print("\n ---------------------------------- \n")
while True:
    cmd = input("Enter command: ")
    
    if(cmd[0] == 'q'):
        #same as ctrlC
        motorControl.stop()
        encoders.cleanUp()
        sensors.lSensor.stop_ranging()
        sensors.fSensor.stop_ranging()
        sensors.rSensor.stop_ranging()
        print("\n ---------------------------------- \n")
        print("Bye bye!")
        break
    
    elif(cmd[0] == '1'):
        if success:     # speeds chart set
            print("Running task 1...")
            task1.run()
    
    elif(cmd[0] == '2'):
        if success: # speeds chart set
            print("Running task 2...")
            task2.run()

    
    elif(cmd[0] == '3'):
        if success: # speeds chart set
            print("Running task 3...")
            task3.run()
    
    elif(cmd[0] == 'c'):
        print("calibrating...")
        motorControl.calibrateSpeeds()
        success = motorControl.setChart()
    
    elif(cmd[0] == '.'):
        print("Plotin' chart")
        task2.plotChart()

    else:
        print("Invalid command, try again!")
    
    print('\n')
    
    





# #motorControl.calibrateSpeeds()
# motorControl.setChart()
# # for k in sorted(motorControl.chart.keys()):
# #     print (k,motorControl.chart[k])
# task1.run()