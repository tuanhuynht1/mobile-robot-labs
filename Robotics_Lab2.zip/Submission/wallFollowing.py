import motorControl
import sensors
import wallDistance as wd
import encoders
import time
import math
import signal

KP = 1
K2 = 1.5
OPENING = 16

lTurns = 0
rTurns = 0
uTurns = 0

distTraveled = 0
distChart = {}
MAXDIST = 30 #max sensor distance in inches
def ctrlC(signum, frame):
    global distTraveled, distChart
    distTraveled += (encoders.getCounts()[0]) * motorControl.IPT
    motorControl.stop()
    encoders.cleanUp()
    sensors.lSensor.stop_ranging()
    sensors.fSensor.stop_ranging()
    sensors.rSensor.stop_ranging()
    sensors.writeCSV(distChart)
    print('\n\n\n ****** Final Info *********')
    printInfo()
    exit()

# signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+ signal interrupt
def run():
    global distChart
    wallToFollow = ''
    sec = 0.0

    signal.signal(signal.SIGINT, ctrlC)# Attach the Ctrl+C signal interrupt
    wallToFollow = input("Wall to Follow(L/R): ")
    if(wallToFollow[0] == 'L'):
        distChart[sec] = sensors.getDistances()
        start = time.monotonic()
        while True:
            currTime = time.monotonic()
            if(currTime >= start+0.1):
                distChart[sec] = sensors.getDistances()
                
                start = time.monotonic()
                sec += 0.1
                
            if(sensors.getLeftDistance()>OPENING):
                print('Turn Left', sensors.getDistances())
                leftTurn()
                print('Onward')
            elif(sensors.getLeftDistance()<=OPENING and sensors.getFrontDistance()>OPENING):
                velocity = wd.linearDesiredVelocity(12,KP)
                speeds = LeftAlignedSpeeds(velocity,K2)
                motorControl.setSpeedsIPS(speeds[0],speeds[1])
            elif(sensors.getLeftDistance()<=OPENING and sensors.getFrontDistance()<=OPENING and sensors.getRightDistance()>OPENING):
                print('Turn Right', sensors.getDistances())
                rightTurn()
                print('Onward')
            elif(sensors.getLeftDistance()<=OPENING and sensors.getFrontDistance()<=12 and sensors.getRightDistance()<=OPENING):
                print('U-Turn')
                uTurn()
                print('Onward')
    elif(wallToFollow[0] == 'R'):
        while True:
            if(sensors.getRightDistance()>OPENING):
                print('Turn Right')
                rightTurn()
                print('Onward')
            elif(sensors.getRightDistance()<=OPENING and sensors.getFrontDistance()>OPENING):
                velocity = wd.linearDesiredVelocity(12,KP)
                speeds = RightAlignedSpeeds(velocity,K2)
                motorControl.setSpeedsIPS(speeds[0],speeds[1])
            elif(sensors.getRightDistance()<=OPENING and sensors.getFrontDistance()<=OPENING and sensors.getLeftDistance()>OPENING):
                print('Turn Left')
                leftTurn()
                print('Onward')
            elif(sensors.getLeftDistance()<=OPENING and sensors.getFrontDistance()<=12 and sensors.getRightDistance()<=OPENING):
                print('U-Turn')
                uTurn()
                print('Onward')

    else:
        print("OOPS")
    return
    
def unstick():
    while(sensors.getFrontDistance() < OPENING):
        rotate(45, 0.5)

def printInfo():
    global lTurns, rTurns, uTurns, distTraveled
    print('Left Turns: ', lTurns, ' Right Turns: ', rTurns, ' U-Turns: ', uTurns)
    print('Distance: ', round(distTraveled, 1), 'inches')

def rotate(degrees,seconds):
    #convert to radians
    degrees = (degrees * math.pi) / 180
    desiredSpeed = degrees/seconds
    if (abs(desiredSpeed) > motorControl.MAX_IPS_W):
        print("Impossible speed")
    
    motorControl.setSpeedsVW(0, desiredSpeed)

    start = time.monotonic()
    while time.monotonic() - start < seconds:
        pass

def leftTurn():
    global lTurns
    global distTraveled
    start = time.monotonic()
    while time.monotonic() - start < 1:
        velocity = wd.linearDesiredVelocity(6,KP)
        motorControl.setSpeedsIPS(velocity,velocity)
        if(sensors.getLeftDistance()<10):
            print ('nvm')
            return
    lTurns += 1
    distTraveled += (encoders.getCounts()[0] - 13) * motorControl.IPT
    rotate(95,0.6)
    encoders.resetCount()
    printInfo()
    while sensors.getLeftDistance()>12:
        velocity = wd.linearDesiredVelocity(6,KP)
        motorControl.setSpeedsIPS(velocity,velocity)
    return

def rightTurn():
    global rTurns
    global distTraveled
    start = time.monotonic()
    while time.monotonic() - start < 1:
        velocity = wd.linearDesiredVelocity(6,KP)
        motorControl.setSpeedsIPS(velocity,velocity)
        if(sensors.getRightDistance()<10 or sensors.getLeftDistance()>OPENING):
            print ('nvm')
            return
    rTurns += 1
    distTraveled += (encoders.getCounts()[0] - 13) * motorControl.IPT
    rotate(-95,0.6)
    encoders.resetCount()
    printInfo()
    while sensors.getRightDistance()>12:
        velocity = wd.linearDesiredVelocity(6,KP)
        motorControl.setSpeedsIPS(velocity,velocity)
    return

def uTurn():
    global uTurns
    global distTraveled
    distTraveled += (encoders.getCounts()[0] - 25) * motorControl.IPT
    rotate(190,1.2)
    #encoders.resetCount()
    uTurns += 1
    printInfo()
    velocity = wd.linearDesiredVelocity(12,KP)
    motorControl.setSpeedsIPS(velocity,velocity)
    return

# def LeftAlignedSpeeds(linearVelocity,Kp):
    # #lDesired = 4
    # tollerance = 0.05
    # ldist = sensors.getLeftDistance()
    # rdist = sensors.getRightDistance()
    # if(ldist and rdist < OPENING):
    #     if (ldist-rdist > tollerance):
    #         error = min(ldist - rdist, Kp)
    #         #left wheel should slow down to move closer to the left
    #         if linearVelocity > 0:    
    #             return linearVelocity - error , linearVelocity
    #         else:
    #             return linearVelocity, linearVelocity - error

    #     elif(ldist-rdist < -1*tollerance):
    #         error = min(rdist - ldist, Kp)
    #         #left wheel should slow down to move closer to the left
    #         if linearVelocity > 0:
    #             return linearVelocity, linearVelocity - error
    #         else:
    #             return linearVelocity - error , linearVelocity
    # else:
    #     return linearVelocity, linearVelocity
def LeftAlignedSpeeds(linearVelocity,Kp):
    
    tollerance = 0.01
    ldist = sensors.getLeftDistance()
    rdist = sensors.getRightDistance()
    
    if(ldist > 13 or rdist > 13):
        return linearVelocity, linearVelocity
    if (ldist-rdist > tollerance):
        error = min(ldist - rdist, Kp)
        #left wheel should slow down to move closer to the left
        if linearVelocity > 0:    
            return linearVelocity - error , linearVelocity
        else:
            return linearVelocity, linearVelocity - error

    elif(ldist-rdist < -1*tollerance):
        error = min(rdist - ldist, Kp)
        #left wheel should slow down to move closer to the left
        if linearVelocity > 0:
            return linearVelocity, linearVelocity - error
        else:
            return linearVelocity - error , linearVelocity
    else:
        return linearVelocity, linearVelocity

def RightAlignedSpeeds(linearVelocity,Kp):
    rDesired = 4
    tollerance = 0.05
    ldist = sensors.getLeftDistance()
    rdist = sensors.getRightDistance()
    
    if (rdist-rDesired > tollerance): #too far away from the right wall
        error = min(rdist - ldist, Kp)
        #right wheel should slow down to move closer to the right
        if linearVelocity > 0:    
            return linearVelocity , linearVelocity - error
        else:
            return linearVelocity - error, linearVelocity

    elif(rdist-rDesired < -1*tollerance): #too close to the right wall
        error = min(ldist - rdist, Kp)
        #right wheel should slow down to move closer to the right
        if linearVelocity > 0:
            return linearVelocity - error, linearVelocity
        else:
            return linearVelocity , linearVelocity - error
    else:
        return linearVelocity, linearVelocity

