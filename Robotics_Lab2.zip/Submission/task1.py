import motorControl
# import encoders
# import sys
# import signal
# import json
import time
import sensors

def run():
    distChart = {}
    motorControl.setSpeedsRPS(.6,.6)
    start = time.monotonic()
    elapse = 0
    i=0
    while (sensors.getFrontDistance() > 12):
        if(elapse == 0):
            distChart[i] = sensors.getDistances()
            i+=0.1
        else:
            elapse = time.monotonic() - start
        if(elapse > 0.1):
            elapse = 0
            start = time.monotonic()
        
    motorControl.stop()
    print (sensors.getDistances()[1])
    sensors.writeCSV(distChart)