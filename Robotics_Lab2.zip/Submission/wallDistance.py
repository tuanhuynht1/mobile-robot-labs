import motorControl
# import encoders
# import sys
# import signal
# import json
import time
import sensors

DESIRED = 12

def run():
    plotChart()
    # Kp = float(input("\nEnter value for Kp: "))
    # while True:
    #     velocity = linearDesiredVelocity(DESIRED,Kp)
    #     if abs(sensors.getFrontDistance() - DESIRED) > 1:
    #         print("yes adjustment")
    #         speeds = lateralAlignedSpeeds(velocity,Kp)
    #         motorControl.setSpeedsIPS(speeds[0],speeds[1])
    #     else:
    #         print("no adjustment")
    #         motorControl.setSpeedsIPS(velocity,velocity)
    #     print(sensors.getFrontDistance())


def plotChart():
    Kp = float(input("\nEnter value for Kp: "))
    distChart = {}
    sec = 0.0
    while sec <= 10:
        distChart[sec] = sensors.getDistances()
        start = time.monotonic()
        while time.monotonic() - start < 0.1:
            velocity = linearDesiredVelocity(DESIRED,Kp)
            speeds = lateralAlignedSpeeds(velocity,2)
            motorControl.setSpeedsIPS(speeds[0],speeds[1])
        sec += 0.1
    motorControl.stop()
    sensors.writeCSV(distChart)

def saturateLinear(velocity):
    if(velocity > motorControl.MAX_IPS):
        velocity = motorControl.MAX_IPS
    elif(velocity < -1*motorControl.MAX_IPS):
        velocity = -1*motorControl.MAX_IPS
    return velocity

def linearDesiredVelocity(desiredDist,Kp):
    # e(t) = r(t) - y(t)
    error = desiredDist - sensors.getFrontDistance()
    error = error * -1 # adjust velocity based on robot's perspective

    # u(t) = Kp * e(t)
    velocity = Kp * error

    #u_r(t) = fsat(u(t))
    velocity = saturateLinear(velocity)
    
    # motorControl.setSpeedsIPS(velocity,velocity)
    return velocity

# def saturateLateral(velocity , linearVelocity):
    
def lateralAlignedSpeeds(linearVelocity,Kp):
    ldist = sensors.getLeftDistance()
    rdist = sensors.getRightDistance()
    

    if (ldist > rdist):
        error = min(ldist - rdist, Kp)
        #left wheel should slow down to move closer to the left
        if linearVelocity > 0:    
            return linearVelocity - error , linearVelocity
        else:
            return linearVelocity, linearVelocity - error

    else:
        error = min(rdist - ldist, Kp)
        #left wheel should slow down to move closer to the left
        if linearVelocity > 0:
            return linearVelocity, linearVelocity - error
        else:
            return linearVelocity - error , linearVelocity



